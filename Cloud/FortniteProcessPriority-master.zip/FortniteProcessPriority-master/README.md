# FortniteProcessPriority

These registry entries allow you to set Fortnite's process priority permanently. I made these .reg files because EasyAntiCheat wouldn't let me change my priority. This is better because now I don't have to use Task Manager every time.

Installation instructions:
Click "Code" (the green button), extract the file you need and double click it.
